# ControlAppPreProject

Para realizar testes no código utilize o nome 'felipe' como e-mail e a '123' como senha, ambos sem aspas. 
A aplicação foi desenvolvida tendo em mente a atividade avaliatória e procurando se basear ao máximo na ideia do que será o aplicativo real quando finalizado. 
